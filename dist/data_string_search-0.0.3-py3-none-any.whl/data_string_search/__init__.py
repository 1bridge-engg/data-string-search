name = "data_string_search"

from .function import search